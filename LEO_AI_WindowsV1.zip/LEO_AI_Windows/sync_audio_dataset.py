# -*- coding: utf-8 -*-
"""Scan audio datasets and update the LEO JSON audio index."""
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))
AUDIO_DIR = os.path.join(HERE, "audio datasets")
DB_PATH = os.path.join(HERE, "leo_commands.json")
EXTENSIONS = {".mp3", ".wav", ".ogg", ".flac", ".m4a"}

def main():
    os.makedirs(AUDIO_DIR, exist_ok=True)
    try:
        with open(DB_PATH, "r", encoding="utf-8") as f:
            db = json.load(f)
    except Exception:
        db = {"version": 1, "commands": [], "audio_index": {}}

    db.setdefault("commands", [])
    db.setdefault("audio_index", {})
    existing = set(db["audio_index"].keys())
    found = []
    for filename in sorted(os.listdir(AUDIO_DIR)):
        if os.path.splitext(filename)[1].lower() in EXTENSIONS:
            found.append(filename)
            db["audio_index"][filename] = {
                "path": os.path.join("audio datasets", filename).replace("\\\\", "/"),
                "registered": True
            }

    with open(DB_PATH, "w", encoding="utf-8") as f:
        json.dump(db, f, ensure_ascii=False, indent=2)

    new_files = [f for f in found if f not in existing]
    print("LEO Audio Dataset Scanner")
    print("=========================")
    print(f"Audio files found: {len(found)}")
    print(f"New files registered: {len(new_files)}")
    for filename in new_files:
        print(" + " + filename)
    print()
    print("The files are indexed. To use a new clip for an action, open leo_commands.json")
    print("and set that command's 'audio' field to the exact filename, including .mp3,")
    print("or use an existing semantic key such as google / youtube / terminal / notepad.")
    input("Press Enter to close...")

if __name__ == "__main__":
    main()
