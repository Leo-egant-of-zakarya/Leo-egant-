@echo off
chcp 65001 >nul
cd /d "%~dp0"
python main.py
if errorlevel 1 (
 echo.
 echo LEO could not start. Run install.bat first and check README.txt.
 pause
)
