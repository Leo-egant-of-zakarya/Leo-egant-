LEO AI Assistant - Windows starter project
===========================================

This is the first working starter version of LEO. It is a local Windows desktop app,
uses your supplied animated GIF as its main visual, and is intended to be developed further.

WHAT WORKS
- Desktop interface with animated LEO GIF
- Text commands and spoken replies (when pyttsx3 is installed)
- Open Google and YouTube in the default browser
- Open Windows Notepad and Calculator
- Weather lookup for a city using the free Open-Meteo APIs
- Hands-free wake phrase: say "Open LEO", then speak your command (SpeechRecognition + Google recognition; requires internet)
- The old "تحدث" button has been replaced by a voice-only wake phrase indicator

REQUIREMENTS
- Windows 10/11
- Python 3.10 or 3.11 recommended
- Internet required for installing packages, voice recognition, and weather lookup
- Microphone required for voice input
- The app listens for the wake phrase while open; it does not save recordings, but speech recognition sends audio to Google's recognition service

INSTALL
1. Extract the ZIP to a normal folder, for example Desktop\LEO_AI_Windows.
2. Install Python from https://www.python.org/downloads/windows/
   During installation, tick "Add python.exe to PATH".
3. Double-click install.bat and wait for installation.
4. Double-click run.bat to launch LEO.

EXAMPLE COMMANDS
- شنو سميتك؟
- افتح جوجل
- شغل يوتيوب
- افتح المفكرة
- افتح الآلة الحاسبة
- حالة الطقس في فاس
- بحث عن الأمن السيبراني

IMPORTANT
- This version is an assistant application, not a new AI model trained from scratch.
- The first version uses rule-based commands; its general conversation can be expanded later
  by connecting a local model such as Ollama.
- Weather and microphone speech recognition need internet.
- The microphone stays active while the app is open to detect "Open LEO". Audio is processed for speech recognition by Google's online service; use this only if you're comfortable with that.
- For better privacy and offline speech, a later version can use a local wake-word and speech model.
- Keep the assets folder next to main.py.
- This project is provided as a free starter; Python packages and online services have their own licenses/terms.


VERSION 3 UPDATES
- Wake phrase response: “مرحبا زكرياء”.
- Voice replies address the user as Zakaria (“حاضر زكرياء”).
- Added “Open Terminal” command to open Windows Command Prompt.
- The app tries to select an installed female voice (e.g. Microsoft Zira/Hazel).
  If Windows has no female voice installed, pyttsx3 will use the system default voice.
- Terminal commands recognized include: “Open Terminal”, “Terminal”, “افتح تيرمينال”.


SOUND FIX (V3 SOUND FIX)
- Speech output now uses Windows built-in System.Speech via PowerShell instead of pyttsx3.
- It prefers the first installed Windows female voice. If Windows has no female voice installed,
  it will use the default Windows voice.
- To check/install voices: Windows Settings > Time & language > Speech (or Language & region),
  add a speech voice/language, then restart LEO.
- In Windows PowerShell you can test speech with:
  Add-Type -AssemblyName System.Speech
  $s = New-Object System.Speech.Synthesis.SpeechSynthesizer
  $s.Speak('Hello Zakaria')


AUDIO DATASET + JSON COMMAND DATABASE
=====================================
The "audio datasets" folder contains response clips. LEO now uses pygame to play MP3/WAV
clips for commands instead of relying on Windows text-to-speech for those mapped responses.

Files added to "audio datasets" are automatically indexed into leo_commands.json when LEO
starts. You can also run sync_audio_dataset.py to scan/index files manually.

Main files:
- main.py: the Windows desktop app and command execution.
- leo_commands.json: editable command phrases, action names, audio mappings, and audio index.
- sync_audio_dataset.py: scanner that registers newly added audio files.
- audio datasets/: MP3/WAV voice responses.
- requirements.txt: includes pygame for audio playback.

Default audio mappings:
- wake_greeting -> clip whose name includes "مرحبا زكرياء"
- google -> clip whose name includes "فتحت ليك Google"
- youtube -> clip whose name includes "فتحت ليك YouTube"
- terminal -> clip whose name includes "فتحت ليك terminal"
- notepad -> clip whose name includes "تم فتح المذكرة"
- weather -> clip whose name includes "سوف ابحث عن حالتي طقس"

Important:
1. New clips are automatically discovered and listed in audio_index.
2. A filename alone does not reliably tell the program which action the user meant.
   For a new command, add/edit its command entry in leo_commands.json, including:
   phrases: what LEO should recognize
   action: one of google, youtube, terminal, notepad, calculator, weather, greeting
   audio: exact filename or a semantic key such as google / youtube / terminal / notepad.
3. For new custom actions, the action also needs implementation in main.py; editing JSON alone cannot safely invent arbitrary Windows actions.
4. Install the new dependency by running install.bat again after updating this project.
5. Voice recognition remains internet-based via Google Speech Recognition. Audio playback of local clips works offline once dependencies are installed.


V5 CHANGES: WAKE WORD, CMD, AND MUSIC LINKS
===========================================
- Wake word changed from "Open LEO" to "Leo" (English recognition; internet required).
- New voice command: "افتح CMD", "Open CMD", or "CMD" opens Windows Command Prompt.
- New editable database: leo_music.json
- Say "موسيقى" / "شغل موسيقى" / "music" to open the first enabled matching link in Google Chrome.
- Default music link is YouTube Music: https://music.youtube.com/
- To add a video/music link, edit leo_music.json and add an object to "links", for example:
  {
    "id": "my_song",
    "name": "My YouTube Video",
    "url": "https://www.youtube.com/watch?v=VIDEO_ID",
    "phrases": ["موسيقى", "شغل الأغنية"],
    "enabled": true,
    "audio": "youtube"
  }
- Use distinct phrases for different links; if multiple enabled entries use the same phrase, the first matching entry opens.
- Chrome is launched directly when found in common install locations; if not found, LEO falls back to the default browser.
- "Leo" is detected through online speech recognition, so microphone and internet are required.


V6: MINIMAL ORB UI + VOLUME COMMANDS
====================================
- Main window now shows only the large animated LEO GIF centered on a dark background,
  with the welcome text below: "مرحبا! أنا ليو / جرب تسولني: شنو سميتك؟"
- Volume commands set Windows master volume to a chosen percentage:
  "ليو اخفضي صوت الى 60/50/40/20/10"
  "ليو ارفع صوت الى 60/50/40/20/10"
  Note: both commands set the volume to the stated exact percentage, as requested.
- Windows master volume uses pycaw/comtypes; run install.bat again to install these dependencies.
- Wake word remains "Leo". Voice recognition requires microphone and internet as before.
- Optional text input can be shown with Ctrl+Shift+L.


V7 - ANIMATED LEO ORB
- Uses the provided cyan/orange digital-head artwork as the main animated interface.
- When LEO plays a voice clip or speaks with Windows TTS, the glowing yellow mouth animation activates; it returns to idle afterwards.
- Existing commands, JSON command database, music database, audio datasets, and volume controls are preserved.
- Volume command regex corrected to accept Arabic wording and levels 10/20/40/50/60.
Note: animation is a visual speaking effect; it is not AI-generated phoneme-perfect lip sync. Test voice playback on your Windows PC.
