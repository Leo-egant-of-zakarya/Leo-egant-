@echo off
chcp 65001 >nul
title LEO AI - Installation
cd /d "%~dp0"
echo ============================================
echo      LEO AI Assistant - Installer
echo ============================================
where python >nul 2>nul
if errorlevel 1 (
  echo Python is not installed or not added to PATH.
  echo Install Python 3.11 from https://www.python.org/downloads/windows/
  echo During installation, select "Add python.exe to PATH".
  pause
  exit /b 1
)
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
if errorlevel 1 (
  echo.
  echo Some packages could not be installed.
  echo PyAudio may require a compatible wheel or Python version.
  echo You can still run the typed-command app after installing Pillow, pyttsx3, and requests.
  pause
  exit /b 1
)
echo.
echo Installation complete. Double-click run.bat to start LEO.
pause
