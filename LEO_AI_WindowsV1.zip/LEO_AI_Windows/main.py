import os
import tkinter as tk
from tkinter import messagebox
import threading
import subprocess
import webbrowser
import datetime
import urllib.parse
import requests
import json
import unicodedata
import re

try:
    import pygame
except ImportError:
    pygame = None

try:
    from PIL import Image, ImageTk, ImageSequence
except ImportError:
    Image = ImageTk = ImageSequence = None

try:
    import pyttsx3
except ImportError:
    pyttsx3 = None

try:
    import speech_recognition as sr
except ImportError:
    sr = None

APP_NAME = "LEO"
BG = "#030914"
PANEL = "#061427"
BLUE = "#00B7FF"
CYAN = "#33E7FF"
WHITE = "#EAF7FF"
MUTED = "#8BA9C7"

class LeoApp:
    def __init__(self, root):
        self.root = root
        self.root.title("LEO | AI Assistant")
        self.root.geometry("1120x760")
        self.root.minsize(900, 650)
        self.root.configure(bg=BG)
        self.busy = False
        self.wake_listener_running = False
        self.stop_wake_listener = threading.Event()
        self.tts = None
        if pyttsx3:
            try:
                self.tts = pyttsx3.init()
                self.tts.setProperty("rate", 170)
                # Prefer an installed female Windows voice when available.
                try:
                    voices = self.tts.getProperty("voices")
                    female_keywords = ("zira", "hazel", "female", "jenny", "aria", "eva", "susan")
                    for voice in voices:
                        description = (str(getattr(voice, "name", "")) + " " + str(getattr(voice, "id", ""))).lower()
                        if any(word in description for word in female_keywords):
                            self.tts.setProperty("voice", voice.id)
                            break
                except Exception:
                    pass
            except Exception:
                self.tts = None
        self.audio_dir = os.path.join(os.path.dirname(__file__), "audio datasets")
        self.db_path = os.path.join(os.path.dirname(__file__), "leo_commands.json")
        self.command_db = self._load_command_db()
        self.music_db_path = os.path.join(os.path.dirname(__file__), "leo_music.json")
        self.music_db = self._load_music_db()
        self.audio_player_ready = False
        if pygame:
            try:
                pygame.mixer.init()
                self.audio_player_ready = True
            except Exception:
                self.audio_player_ready = False
        self.gif_frames = []
        self.talking_frames = []
        self.active_frames = []
        self.is_talking = False
        self.gif_index = 0
        self._build_ui()
        self.root.protocol("WM_DELETE_WINDOW", self.close_app)
        self._load_gif()
        self._animate_gif()
        self.say("مرحبا! أنا ليو، المساعد الذكي ديالك. كيف نقدر نعاونك؟", show=False)
        self.set_status("كنستنى Leo")
        if sr:
            self.root.after(1200, self.start_wake_listener)
        else:
            self.root.after(1200, lambda: self.show_reply("خاص تثبيت مكتبة الصوت. شوف README.txt"))

    def close_app(self):
        self.stop_wake_listener.set()
        self.root.destroy()

    def _build_ui(self):
        # Full-window cosmic HUD: animated matrix particles + avatar + live status.
        self.root.geometry("1200x900")
        self.root.minsize(800, 650)
        self.root.configure(bg="#020711")
        self.root.bind("<Escape>", lambda e: self.root.attributes("-fullscreen", False))
        self.root.bind("<F11>", lambda e: self.root.attributes("-fullscreen", not self.root.attributes("-fullscreen")))
        self.canvas = tk.Canvas(self.root, bg="#020711", highlightthickness=0, bd=0)
        self.canvas.pack(fill="both", expand=True)
        self._hud_particles = []
        self.current_reply = "مرحبا! أنا ليو\\nجرب تسولني: شنو سميتك؟"
        self.current_status = "كنستنى كلمة LEO"
        self._hud_photo = None
        self._hud_bg_id = None
        self._hud_avatar_id = None
        self._hud_status_id = None
        self._hud_greeting_id = None
        self._hud_subtitle_id = None
        self._hud_panel_ids = []
        self.reply = tk.Label(self.root, text="مرحبا! أنا ليو\\nجرب تسولني: شنو سميتك؟",
            fg="#EAF7FF", bg="#020711", font=("Segoe UI", 16, "bold"),
            justify="center", wraplength=760, padx=12, pady=8)
        self.status = tk.Label(self.root, text="● كنستنى كلمة LEO",
            fg="#33E7FF", bg="#020711", font=("Segoe UI", 10))
        self.voice_status = self.status
        self.entry = tk.Entry(self.root)
        self.entry.bind("<Return>", lambda e: self.send_text())
        self.root.bind("<Control-Shift-L>", self._show_text_entry)
        self.canvas.bind("<Configure>", self._on_hud_resize)
        self._make_hud_particles(95)

    def _make_hud_particles(self, count):
        import random
        self._hud_particles = []
        for _ in range(count):
            self._hud_particles.append({
                "x": random.random(), "y": random.random(),
                "speed": random.uniform(0.0015, 0.008),
                "size": random.choice([1, 1, 2, 2, 3]),
                "gold": random.random() < 0.22,
                "phase": random.random() * 6.28
            })

    def _on_hud_resize(self, event=None):
        if not hasattr(self, "canvas"):
            return
        self._draw_hud()
        if not getattr(self, "_hud_animation_started", False):
            self._hud_animation_started = True
            self._animate_hud()

    def _draw_hud(self):
        if not hasattr(self, "canvas"):
            return
        c = self.canvas
        c.delete("all")
        w = max(c.winfo_width(), 800)
        h = max(c.winfo_height(), 650)
        # Fill the complete window with a dark cosmic base and a faint grid.
        c.configure(bg="#020711")
        for x in range(0, w, 48):
            c.create_line(x, 0, x, h, fill="#06192A", width=1)
        for y in range(0, h, 48):
            c.create_line(0, y, w, y, fill="#06192A", width=1)
        # Subtle HUD corner brackets.
        self._hud_panel(c, 22, 22, min(290, w*0.27), 82, "LEO  /  AI ASSISTANT", "NEURAL VOICE SYSTEM")
        self._hud_panel(c, w-min(300,w*0.28)-22, 22, w-22, 82, "● LIVE LISTENING", "Say: LEO")
        # Main avatar animation remains large and centered.
        frames = self.active_frames or self.gif_frames
        if frames:
            frame, _ = frames[self.gif_index % len(frames)]
            self._hud_avatar_id = c.create_image(w*0.5, h*0.48, image=frame, anchor="center")
        else:
            c.create_oval(w*.28,h*.12,w*.72,h*.72,outline="#00DFFF",width=3)
        # Functional-looking side HUD panels (visual labels only; commands remain voice driven).
        self._hud_panel(c, 22, 126, min(255,w*.23), h-150, "VOICE COMMANDS",
            "Google  •  YouTube\\nTerminal  •  CMD\\nNotepad  •  Calculator\\nWeather  •  Search\\nMusic links\\nVolume 10–100%")
        self._hud_panel(c, w-min(255,w*.23)-22, 126, w-22, h-150, "SYSTEM STATUS",
            "Wake word: LEO\\nVoice replies: enabled\\nAudio datasets: loaded\\nMusic database: ready\\nPress F11: fullscreen\\nCtrl+Shift+L: type command")
        # Greeting panel anchored near bottom.
        panel_w=min(620,w-60)
        x1=(w-panel_w)/2; y1=h-125
        c.create_rectangle(x1,y1,x1+panel_w,h-24,fill="#031222",outline="#FFC342",width=2)
        c.create_line(x1+16,y1+8,x1+100,y1+8,fill="#FFC342",width=3)
        c.create_text(w/2,y1+42,text=self.current_reply,fill="#FFC342",
                      font=("Segoe UI",13,"bold"),width=panel_w-35,justify="center")
        self._hud_status_id = c.create_text(w/2, h-148, text="● " + self.current_status,
            fill="#55EFFF", font=("Segoe UI", 10, "bold"))
        # Recreate hidden labels only for existing methods expecting widgets.
        self.reply.place_forget()
        self.status.place_forget()

    def _hud_panel(self, canvas, x1, y1, x2, y2, title, body):
        canvas.create_rectangle(x1,y1,x2,y2,fill="#031222",outline="#00CFFF",width=2)
        canvas.create_line(x1+12,y1+8,x1+90,y1+8,fill="#FFC342",width=3)
        canvas.create_text(x1+14,y1+18,text=title,anchor="w",fill="#38E9FF",
                           font=("Segoe UI", 11, "bold"))
        if body:
            canvas.create_text(x1+14,y1+43,text=body,anchor="nw",fill="#D6F7FF",
                               font=("Segoe UI", 9),width=max(120,x2-x1-28))

    def _animate_hud(self):
        if not hasattr(self, "canvas") or not self.canvas.winfo_exists():
            return
        c=self.canvas
        c.delete("particles")
        c.delete("waveform")
        w=max(c.winfo_width(),800); h=max(c.winfo_height(),650)
        # Matrix-like particles drift down and reset at the top.
        for p in self._hud_particles:
            p["y"] += p["speed"]
            p["x"] += 0.0004 * (1 if int(p["phase"]*10)%2 else -1)
            if p["y"] > 1.02:
                p["y"] = -0.02
                p["x"] = random.random()
            color = "#FFC342" if p["gold"] else "#00DFFF"
            x=p["x"]*w; y=p["y"]*h; r=p["size"]
            # keep particles visible over the whole interface
            c.create_oval(x-r,y-r,x+r,y+r,fill=color,outline="",tags="particles")
            if p["size"] >= 2:
                c.create_line(x,y-12,x,y-4,fill=color,width=1,tags="particles")
        # glowing voice waveform along the bottom edge of the avatar
        import math, time
        t=time.time()
        cy=h*0.72
        for i in range(45):
            x=w*0.32+i*(w*0.36/44)
            amp=5+abs(math.sin(t*3+i*.58))* (18 if self.is_talking else 5)
            c.create_line(x,cy-amp,x,cy+amp,fill="#FFC342" if i%4==0 else "#00DFFF",width=2,tags="waveform")
        # redraw on top at ~30 fps; particle count is intentionally modest.
        self.root.after(40, self._animate_hud)

    def _clear_placeholder(self, event):
        if self.entry.get() == "اكتب الأمر ديالك هنا...":
            self.entry.delete(0, "end")

    def _read_gif_frames(self, filename, size=(620, 760)):
        frames = []
        path = os.path.join(os.path.dirname(__file__), "assets", filename)
        gif = Image.open(path)
        for frame in ImageSequence.Iterator(gif):
            frame = frame.convert("RGBA")
            frame.thumbnail(size, Image.Resampling.LANCZOS)
            frames.append((ImageTk.PhotoImage(frame), max(40, frame.info.get("duration", 100))))
        return frames

    def _load_gif(self):
        if not Image:
            self.gif_frames = []
            self.talking_frames = []
            return
        try:
            self.gif_frames = self._read_gif_frames("leo_orb.gif")
            self.talking_frames = self._read_gif_frames("leo_talking.gif")
            self.active_frames = self.gif_frames
        except Exception:
            self.gif_frames = []
            self.talking_frames = []

    def _animate_gif(self):
        # The HUD renderer draws the current avatar frame on each animation tick.
        if self.gif_frames:
            self.gif_index = (self.gif_index + 1) % len(self.gif_frames)
        if hasattr(self, "canvas") and self.canvas.winfo_exists():
            self._draw_hud()
        self.root.after(120, self._animate_gif)

    def set_status(self, text):
        self.current_status = text
        try:
            if hasattr(self, "_hud_status_id") and self._hud_status_id:
                self.canvas.itemconfigure(self._hud_status_id, text="● " + text)
            else:
                self.status.config(text="● " + text, fg="#38E89B")
        except Exception:
            pass

    def show_reply(self, text):
        self.current_reply = text
        try:
            if hasattr(self, "canvas") and self.canvas.winfo_exists():
                w=max(self.canvas.winfo_width(),800); h=max(self.canvas.winfo_height(),650)
                panel_w=min(620,w-60); x1=(w-panel_w)/2; y1=h-125
                self.canvas.create_rectangle(x1,y1,x1+panel_w,h-24,fill="#031222",outline="#FFC342",width=2)
                self.canvas.create_text(w/2,y1+30,text=text,fill="#FFC342",
                    font=("Segoe UI",13,"bold"),width=panel_w-35,justify="center")
            else:
                self.reply.config(text=text)
        except Exception:
            pass

    def _load_command_db(self):
        """Load the editable JSON database and register newly added audio files."""
        default_db = {
            "version": 1,
            "commands": [
                {"id": "google", "phrases": ["open google", "google", "جوجل", "غوغل"], "action": "google", "audio": "google"},
                {"id": "youtube", "phrases": ["open youtube", "youtube", "يوتيوب"], "action": "youtube", "audio": "youtube"},
                {"id": "terminal", "phrases": ["open terminal", "terminal", "افتح تيرمينال", "افتح ترمينال", "تيرمينال", "ترمينال"], "action": "terminal", "audio": "terminal"},
                {"id": "notepad", "phrases": ["open notepad", "notepad", "افتح المفكرة", "افتح المذكرة", "مفكرة", "مذكرة"], "action": "notepad", "audio": "notepad"},
                {"id": "calculator", "phrases": ["open calculator", "calculator", "الآلة الحاسبة", "الحاسبة"], "action": "calculator", "audio": "calculator"},
                {"id": "weather", "phrases": ["weather", "حالة الطقس", "الطقس", "الجو", "طقس"], "action": "weather", "audio": "weather"},
                {"id": "wake_greeting", "phrases": [], "action": "greeting", "audio": "wake_greeting"}
            ],
            "audio_index": {},
            "notes": "أضف ملفاً صوتياً إلى مجلد audio datasets؛ سيظهر تلقائياً في audio_index عند تشغيل ليو. لربطه بأمر، ضع اسم الملف في حقل audio لذلك الأمر."
        }
        try:
            with open(self.db_path, "r", encoding="utf-8") as f:
                db = json.load(f)
        except Exception:
            db = default_db
        # Keep the default command rules while preserving user edits.
        if not isinstance(db, dict):
            db = default_db
        if not isinstance(db.get("commands"), list):
            db["commands"] = default_db["commands"]
        if not isinstance(db.get("audio_index"), dict):
            db["audio_index"] = {}
        os.makedirs(self.audio_dir, exist_ok=True)
        for filename in os.listdir(self.audio_dir):
            if filename.lower().endswith((".mp3", ".wav", ".ogg", ".flac", ".m4a")):
                db["audio_index"][filename] = {
                    "path": os.path.join("audio datasets", filename),
                    "registered": True
                }
        try:
            with open(self.db_path, "w", encoding="utf-8") as f:
                json.dump(db, f, ensure_ascii=False, indent=2)
        except Exception:
            pass
        return db

    def _load_music_db(self):
        """Load user-editable music/video links. Users can add their own YouTube URLs."""
        default_db = {
            "version": 1,
            "default_browser": "chrome",
            "links": [
                {
                    "id": "music_default",
                    "name": "YouTube Music",
                    "url": "https://music.youtube.com/",
                    "phrases": ["موسيقى", "شغل موسيقى", "افتح الموسيقى", "music", "play music"],
                    "enabled": True
                }
            ],
            "notes": "أضف روابط YouTube أو فيديوهات في links. عند قول موسيقى يفتح أول رابط enabled. تأكد أن الرابط يبدأ بـ https://"
        }
        try:
            with open(self.music_db_path, "r", encoding="utf-8") as f:
                db = json.load(f)
            if not isinstance(db, dict) or not isinstance(db.get("links"), list):
                return default_db
            return db
        except Exception:
            try:
                with open(self.music_db_path, "w", encoding="utf-8") as f:
                    json.dump(default_db, f, ensure_ascii=False, indent=2)
            except Exception:
                pass
            return default_db

    def _open_in_chrome(self, url):
        """Prefer Chrome; if Chrome isn't installed, fall back to the default browser."""
        if not isinstance(url, str) or not url.startswith(("https://", "http://")):
            raise ValueError("رابط غير صالح")
        candidates = [
            os.path.expandvars(r"%ProgramFiles%\\Google\\Chrome\\Application\\chrome.exe"),
            os.path.expandvars(r"%ProgramFiles(x86)%\\Google\\Chrome\\Application\\chrome.exe"),
            os.path.expandvars(r"%LocalAppData%\\Google\\Chrome\\Application\\chrome.exe"),
        ]
        chrome = next((p for p in candidates if os.path.isfile(p)), None)
        if chrome:
            subprocess.Popen([chrome, url])
            return True
        try:
            webbrowser.get("chrome").open(url)
            return True
        except Exception:
            webbrowser.open(url)
            return False

    def _run_music_command(self, command):
        normalized = self._normalize_command(command)
        links = self.music_db.get("links", [])
        for item in links:
            if not item.get("enabled", True):
                continue
            phrases = [self._normalize_command(x) for x in item.get("phrases", [])]
            if any(p and (normalized == p or p in normalized) for p in phrases):
                url = item.get("url", "")
                try:
                    self._open_in_chrome(url)
                    self.say("حاضر زكرياء، كنفتح ليك الموسيقى.", audio_key=item.get("audio") or "youtube")
                except Exception:
                    self.say("سمح ليا زكرياء، الرابط الموجود فقاعدة الموسيقى غير صالح.")
                return True
        return False

    @staticmethod
    def _normalize_command(text):
        text = unicodedata.normalize("NFKC", str(text)).lower().strip()
        text = re.sub(r"[؟?!.,،:;؛]+", " ", text)
        return " ".join(text.split())

    def _find_audio_file(self, audio_key):
        if not audio_key:
            return None
        # JSON command may refer to an exact filename or a semantic audio key.
        index = self.command_db.get("audio_index", {})
        if audio_key in index:
            candidate = os.path.join(os.path.dirname(__file__), index[audio_key].get("path", ""))
            if os.path.isfile(candidate):
                return candidate
        # Exact filename references are also supported.
        direct = os.path.join(self.audio_dir, audio_key)
        if os.path.isfile(direct):
            return direct
        aliases = {
            "wake_greeting": ["مرحبا زكرياء"],
            "google": ["فتحت ليك google", "فتحت ليك Google"],
            "youtube": ["فتحت ليك YouTube", "فتحت ليك Youtube"],
            "terminal": ["فتحت ليك terminal", "فتحت ليك terminal"],
            "notepad": ["تم فتح المذكرة"],
            "weather": ["حاضر زكرياء، سوف ابحث عن حالتي طقس", "سوف ابحث عن حالتي طقس"],
            "calculator": ["تم فتح الآلة الحاسبة", "فتحت ليك الحاسبة"]
        }
        wanted = aliases.get(audio_key, [])
        files = list(index.keys())
        for term in wanted:
            for filename in files:
                if self._normalize_command(term) in self._normalize_command(os.path.splitext(filename)[0]):
                    candidate = os.path.join(self.audio_dir, filename)
                    if os.path.isfile(candidate):
                        return candidate
        return None

    def _play_audio_clip(self, audio_key):
        path = self._find_audio_file(audio_key)
        if not path or not self.audio_player_ready:
            return False
        try:
            # pygame supports MP3/WAV on Windows. Stop the previous clip before playing a new one.
            pygame.mixer.music.stop()
            pygame.mixer.music.load(path)
            pygame.mixer.music.play()
            return True
        except Exception:
            return False

    def say(self, text, show=True, audio_key=None):
        if show:
            self.show_reply(text)
        self.root.after(0, lambda: self._set_talking(True))
        if audio_key and self._play_audio_clip(audio_key):
            def watch_clip():
                import time
                try:
                    while pygame and pygame.mixer.music.get_busy():
                        time.sleep(0.12)
                except Exception:
                    time.sleep(1.2)
                self.root.after(0, lambda: self._set_talking(False))
            threading.Thread(target=watch_clip, daemon=True).start()
            return
        # Fallback to pyttsx3 when no matching clip exists or playback is unavailable.
        if self.tts:
            def speak():
                try:
                    self.tts.say(text)
                    self.tts.runAndWait()
                except Exception:
                    pass
                finally:
                    self.root.after(0, lambda: self._set_talking(False))
            threading.Thread(target=speak, daemon=True).start()
        else:
            self.root.after(1800, lambda: self._set_talking(False))

    def send_text(self):
        text = self.entry.get().strip()
        if not text or text == "اكتب الأمر ديالك هنا...":
            return
        self.entry.delete(0, "end")
        self.handle_command(text)

    def start_wake_listener(self):
        """Wait for the spoken wake word 'Leo', then capture one command."""
        if not sr or self.wake_listener_running:
            return
        self.wake_listener_running = True
        self.stop_wake_listener.clear()
        threading.Thread(target=self._wake_listener_worker, daemon=True).start()

    def _wake_listener_worker(self):
        recognizer = sr.Recognizer()
        try:
            while not self.stop_wake_listener.is_set():
                try:
                    with sr.Microphone() as source:
                        recognizer.adjust_for_ambient_noise(source, duration=0.25)
                        self.root.after(0, lambda: self.set_status("كنستنى Leo"))
                        self.root.after(0, lambda: self.voice_status.config(text="🎙 قل: LEO"))
                        audio = recognizer.listen(source, timeout=3, phrase_time_limit=3)
                    # Wake phrase is English; online recognition requires an internet connection.
                    phrase = recognizer.recognize_google(audio, language="en-US").lower()
                    normalized = phrase.replace(".", "").replace(",", "").strip()
                    if normalized.strip() in {"leo", "lio", "le o", "leo.", "lio."} or normalized.strip().replace(".", "") in {"leo", "lio", "le o"}:
                        self.root.after(0, lambda: self.set_status("تم التفعيل"))
                        self.root.after(0, lambda: self.voice_status.config(text="🟢 ليو كيسمع الأمر"))
                        self.root.after(0, lambda: self.say("مرحبا زكرياء، أنا ليو. تفضل، شنو بغيتي ندير ليك؟", audio_key="wake_greeting"))
                        # Give the spoken prompt time to finish before opening the next capture.
                        import time
                        time.sleep(1.8)
                        with sr.Microphone() as source:
                            recognizer.adjust_for_ambient_noise(source, duration=0.2)
                            audio_command = recognizer.listen(source, timeout=6, phrase_time_limit=8)
                        command = recognizer.recognize_google(audio_command, language="ar-MA")
                        self.root.after(0, lambda c=command: self._process_voice_command(c))
                except sr.WaitTimeoutError:
                    continue
                except sr.UnknownValueError:
                    continue
                except Exception:
                    # Keep the app alive if the microphone or network has a temporary issue.
                    self.root.after(0, lambda: self.set_status("تحقق من الميكروفون/الإنترنت"))
                    import time
                    time.sleep(2)
        finally:
            self.wake_listener_running = False

    def _process_voice_command(self, command):
        self.entry.delete(0, "end")
        self.entry.insert(0, command)
        self.handle_command(command)
        self.voice_status.config(text="🎙 قل: LEO")
        self.set_status("كنستنى Leo")

    def _show_text_entry(self, event=None):
        try:
            self.entry.place(relx=0.5, rely=0.96, anchor="s", width=420, height=34)
            self.entry.focus_set()
        except Exception:
            pass

    def _set_master_volume(self, percent):
        """Set Windows master playback volume (0-100) using pycaw."""
        try:
            from ctypes import cast, POINTER
            from comtypes import CLSCTX_ALL
            from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
            devices = AudioUtilities.GetSpeakers()
            interface = devices.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
            endpoint = cast(interface, POINTER(IAudioEndpointVolume))
            endpoint.SetMasterVolumeLevelScalar(max(0.0, min(1.0, percent / 100.0)), None)
            return True
        except Exception:
            return False

    def handle_command(self, command):
        if not command:
            return
        normalized = self._normalize_command(command)

        # Spoken Windows master-volume commands.
        volume_match = re.search(r"(?:صوت|الصوت)\s*(?:الى|إلى|لحد|لـ)?\s*(10|20|40|50|60)\b", normalized)
        if volume_match and any(word in normalized for word in ["اخفض", "خفض", "نقص", "وطي", "ارفع", "رفع", "زيد", "علي"]):
            level = int(volume_match.group(1))
            if self._set_master_volume(level):
                self.say(f"حاضر زكرياء، ضبطت صوت الحاسوب على {level} بالمئة.")
            else:
                self.say("زكرياء، ما قدرتش نتحكم فالصوت. شغل install.bat لتثبيت مكتبات التحكم بالصوت ثم عاود شغل ليو.")
            return

        # First check editable command phrases from leo_commands.json.
        selected = None
        for item in self.command_db.get("commands", []):
            for phrase in item.get("phrases", []):
                p = self._normalize_command(phrase)
                if p and (normalized == p or p in normalized):
                    selected = item
                    break
            if selected:
                break

        # Music links are managed separately in leo_music.json.
        if self._run_music_command(command):
            return

        # Backward-compatible matching for common commands.
        if not selected:
            if any(x in normalized for x in ["google", "جوجل", "غوغل"]):
                selected = {"action": "google", "audio": "google"}
            elif any(x in normalized for x in ["youtube", "يوتيوب"]):
                selected = {"action": "youtube", "audio": "youtube"}
            elif any(x in normalized for x in ["افتح cmd", "open cmd", "cmd", "command prompt", "موجه الأوامر"]):
                selected = {"action": "cmd", "audio": "terminal"}
            elif any(x in normalized for x in ["open terminal", "terminal", "تيرمينال", "ترمينال", "الطرفية"]):
                selected = {"action": "terminal", "audio": "terminal"}
            elif any(x in normalized for x in ["مفكرة", "مذكرة", "notepad"]):
                selected = {"action": "notepad", "audio": "notepad"}
            elif any(x in normalized for x in ["آلة حاسبة", "الحاسبة", "calculator"]):
                selected = {"action": "calculator", "audio": "calculator"}
            elif any(x in normalized for x in ["طقس", "الجو", "weather"]):
                selected = {"action": "weather", "audio": "weather"}
            elif any(x in normalized for x in ["اسمك", "سميتك", "شكون نتا", "who are you", "your name"]):
                self.say("أنا ليو، المساعد الذكي ديالك!")
                return
            elif any(x in normalized for x in ["مرحبا", "سلام", "السلام عليكم", "hello", "hi"]):
                self.say("وعليكم السلام! مرحبا بك، أنا ليو. شنو نقدر ندير ليك؟", audio_key="wake_greeting")
                return
            elif any(x in normalized for x in ["الوقت", "شحال فالساعة", "time"]):
                self.say("الوقت دابا هو " + datetime.datetime.now().strftime("%H:%M"))
                return
            elif any(x in normalized for x in ["بحث", "قلب", "search"]):
                query = command
                for prefix in ["بحث عن", "قلب على", "قلب ليا على", "search for"]:
                    query = query.replace(prefix, "")
                webbrowser.open("https://www.google.com/search?q=" + urllib.parse.quote(query.strip()))
                self.say("حاضر زكرياء، فتحت ليك نتائج البحث.")
                return
            else:
                self.say("حاضر زكرياء، فهمت الطلب ديالك، ولكن مازال ما تعلمتش هاد المهمة. تقدر تقول Open Google أو Open YouTube أو Open Terminal أو حالة الطقس.")
                return

        action = selected.get("action")
        audio_key = selected.get("audio")
        if action == "google":
            webbrowser.open("https://www.google.com")
            self.say("حاضر زكرياء، فتحت ليك Google.", audio_key=audio_key or "google")
        elif action == "youtube":
            webbrowser.open("https://www.youtube.com")
            self.say("حاضر زكرياء، فتحت ليك YouTube.", audio_key=audio_key or "youtube")
        elif action == "cmd":
            try:
                subprocess.Popen(["cmd.exe"], creationflags=getattr(subprocess, "CREATE_NEW_CONSOLE", 0))
                self.say("حاضر زكرياء، فتحت ليك CMD.", audio_key=audio_key or "terminal")
            except Exception:
                self.say("سمح ليا زكرياء، ما قدرتش نفتح CMD.")
        elif action == "terminal":
            try:
                subprocess.Popen(["cmd.exe"], creationflags=getattr(subprocess, "CREATE_NEW_CONSOLE", 0))
                self.say("حاضر زكرياء، فتحت ليك Terminal.", audio_key=audio_key or "terminal")
            except Exception:
                self.say("سمح ليا زكرياء، ما قدرتش نفتح Terminal.")
        elif action == "notepad":
            try:
                subprocess.Popen(["notepad.exe"])
                self.say("حاضر زكرياء، فتحت ليك المفكرة.", audio_key=audio_key or "notepad")
            except Exception:
                self.say("سمح ليا زكرياء، ما قدرتش نفتح المفكرة.")
        elif action == "calculator":
            try:
                subprocess.Popen(["calc.exe"])
                self.say("حاضر زكرياء، فتحت ليك الآلة الحاسبة.", audio_key=audio_key or "calculator")
            except Exception:
                self.say("سمح ليا زكرياء، ما قدرتش نفتح الآلة الحاسبة.")
        elif action == "weather":
            city = self._extract_city(command)
            self.say(f"حاضر زكرياء، سوف نبحث عن حالة الطقس في {city}.", audio_key=audio_key or "weather")
            threading.Thread(target=self._weather_worker, args=(city,), daemon=True).start()
        elif action == "greeting":
            self.say("مرحبا زكرياء، أنا ليو. تفضل، شنو بغيتي ندير ليك؟", audio_key=audio_key or "wake_greeting")
        else:
            self.say("الأمر موجود في قاعدة البيانات، ولكن خاصنا نربطو بالفعل المناسب داخل main.py.")

    def _extract_city(self, command):
        lower = command.lower()
        for city in ["فاس", "مكناس", "الرباط", "الدار البيضاء", "طنجة", "مراكش", "أكادير", "وجدة", "تطوان", "فاس"]:
            if city in command:
                return city
        return "فاس"

    def _weather_worker(self, city):
        try:
            geo = requests.get("https://geocoding-api.open-meteo.com/v1/search",
                               params={"name": city, "count": 1, "language": "ar", "format": "json"},
                               timeout=10).json()
            results = geo.get("results", [])
            if not results:
                answer = f"ما لقيتش المدينة {city}. جرب اسم مدينة مغربية أخرى."
            else:
                place = results[0]
                weather = requests.get("https://api.open-meteo.com/v1/forecast",
                    params={"latitude": place["latitude"], "longitude": place["longitude"],
                            "current": "temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m",
                            "timezone": "auto"}, timeout=10).json()
                current = weather.get("current", {})
                temp = current.get("temperature_2m", "--")
                feels = current.get("apparent_temperature", "--")
                humidity = current.get("relative_humidity_2m", "--")
                wind = current.get("wind_speed_10m", "--")
                answer = f"الطقس في {place.get('name', city)} دابا: الحرارة {temp} درجة، المحسوسة {feels} درجة، الرطوبة {humidity}%، والرياح {wind} كلم/ساعة."
        except Exception:
            answer = "تعذر جلب الطقس. تأكد من اتصال الإنترنت وحاول مرة أخرى."
        self.root.after(0, lambda: self.say(answer))

def main():
    root = tk.Tk()
    app = LeoApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
